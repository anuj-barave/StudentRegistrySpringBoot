package com.SpringbootRestJpaH2.StudentRegistry.StudentApi;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class StudentServiceImpl implements StudentService{

    @Autowired
    StudentRepository repository;

    @Override
    public Student addStudent(Student student) {
        repository.save(student);
        return student;
    }

    @Override
    public List<Student> retrieveAllStudents() {
        return repository.findAll();
    }

    @Override
    public Student retrieveSpecificStudentById(int studentId) {
        return repository.findById(studentId).orElse(null);
    }

    @Override
    public void updateStudentById(int studentId,Student student) {
            Student OrignalStudent = repository.findById(studentId).orElse(null);
            if(OrignalStudent!=null)
            {
                OrignalStudent.setName(student.getName());
                OrignalStudent.setAddress(student.getAddress());
                OrignalStudent.setBranch(student.getBranch());
            }
    }

    @Override
    public void deleteStudentById(int studentId) {
        Student student = repository.findById(studentId).orElse(null);
        if(student!=null)
        {
            repository.delete(student);
        }

    }


}
