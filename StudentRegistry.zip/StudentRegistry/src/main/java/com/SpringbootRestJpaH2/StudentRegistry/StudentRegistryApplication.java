package com.SpringbootRestJpaH2.StudentRegistry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentRegistryApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentRegistryApplication.class, args);
	}

}
