package com.SpringbootRestJpaH2.StudentRegistry.StudentApi;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class StudentResource {

    @Autowired
    private StudentServiceImpl serviceImpl;

    @RequestMapping(value = "/students",method = RequestMethod.POST)
    public ResponseEntity.BodyBuilder addStudent(@RequestBody Student student)
    {
        Student student1 =  serviceImpl.addStudent(student);
        if(student1!=null)
        {
            return ResponseEntity.accepted();
        }
        return null;
    }

    @RequestMapping("/students")
    public List<Student> retriveAllStuddents()
    {
        return serviceImpl.retrieveAllStudents();
    }

    @RequestMapping(value="/students/{studentId}",method = RequestMethod.GET)
    public Student retriveSpecificStudentById(@PathVariable int studentId)
    {
        return serviceImpl.retrieveSpecificStudentById(studentId);
    }

    @RequestMapping(value="/students/{studentId}",method = RequestMethod.PUT)
    public ResponseEntity<Object> updateStudentById(@PathVariable int studentId , @RequestBody Student student)
    {
        serviceImpl.updateStudentById(studentId,student);
        return ResponseEntity.noContent().build();
    }


    @RequestMapping(value = "/students/{studentId}" ,method = RequestMethod.DELETE)
    public ResponseEntity<Object> deleteStudentById(@PathVariable int studentid)
    {
        serviceImpl.deleteStudentById(studentid);
        return ResponseEntity.noContent().build();
    }












}
